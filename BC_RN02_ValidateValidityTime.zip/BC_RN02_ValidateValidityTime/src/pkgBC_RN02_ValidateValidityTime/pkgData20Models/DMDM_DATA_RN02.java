package pkgBC_RN02_ValidateValidityTime.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="BC_RN02_ValidateValidityTime",DataModelName="DM_DATA_RN02",EventTypeName="") public class DMDM_DATA_RN02 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private Long slotHOURS_MAX;
  private Boolean slotReturn;
  @IDataAnnotation(OriginalFieldName="HOURS_MAX",FieldName="slotHOURS_MAX",SlotKey="/HOURS_MAX;3.7;0",Position=0,CameFromFloat=false) public Long getSlotHOURS_MAX(){
    return this.slotHOURS_MAX;
  }
  @IDataAnnotation(OriginalFieldName="HOURS_MAX",FieldName="slotHOURS_MAX",SlotKey="/HOURS_MAX;3.7;0",Position=0,CameFromFloat=false) public void setSlotHOURS_MAX(  Long paramHOURS_MAX){
    this.slotHOURS_MAX=paramHOURS_MAX;
  }
  @IDataAnnotation(OriginalFieldName="HOURS_MAX",FieldName="slotHOURS_MAX",SlotKey="/HOURS_MAX;3.7;0",Position=0,CameFromFloat=false) public void setSlotHOURS_MAX(  String paramHOURS_MAX){
    if (paramHOURS_MAX != null) {
      this.slotHOURS_MAX=Long.valueOf(paramHOURS_MAX);
    }
 else {
      this.slotHOURS_MAX=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="HOURS_MAX",FieldName="slotHOURS_MAX",SlotKey="/HOURS_MAX;3.7;0",Position=0,CameFromFloat=false) public void setSlotHOURS_MAX(  Double paramHOURS_MAX){
    if (paramHOURS_MAX != null) {
      this.slotHOURS_MAX=paramHOURS_MAX.longValue();
    }
 else {
      this.slotHOURS_MAX=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="Return",FieldName="slotReturn",SlotKey="/Return;3.1;0",Position=1,CameFromFloat=false) public Boolean getSlotReturn(){
    return this.slotReturn;
  }
  @IDataAnnotation(OriginalFieldName="Return",FieldName="slotReturn",SlotKey="/Return;3.1;0",Position=1,CameFromFloat=false) public void setSlotReturn(  Boolean paramReturn){
    this.slotReturn=paramReturn;
  }
}
