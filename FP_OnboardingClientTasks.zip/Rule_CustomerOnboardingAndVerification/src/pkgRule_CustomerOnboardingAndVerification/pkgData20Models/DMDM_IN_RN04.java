package pkgRule_CustomerOnboardingAndVerification.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="Rule_CustomerOnboardingAndVerification",DataModelName="DM_IN_RN04",EventTypeName="") public class DMDM_IN_RN04 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private String slotactivity;
  private String slotsubactivity;
  private String slottypePlace;
  @IDataAnnotation(OriginalFieldName="activity",FieldName="slotactivity",SlotKey="/activity;1;0",Position=0,CameFromFloat=false) public String getSlotactivity(){
    return this.slotactivity;
  }
  @IDataAnnotation(OriginalFieldName="activity",FieldName="slotactivity",SlotKey="/activity;1;0",Position=0,CameFromFloat=false) public void setSlotactivity(  String paramactivity){
    this.slotactivity=paramactivity;
  }
  @IDataAnnotation(OriginalFieldName="subactivity",FieldName="slotsubactivity",SlotKey="/subactivity;1;0",Position=1,CameFromFloat=false) public String getSlotsubactivity(){
    return this.slotsubactivity;
  }
  @IDataAnnotation(OriginalFieldName="subactivity",FieldName="slotsubactivity",SlotKey="/subactivity;1;0",Position=1,CameFromFloat=false) public void setSlotsubactivity(  String paramsubactivity){
    this.slotsubactivity=paramsubactivity;
  }
  @IDataAnnotation(OriginalFieldName="typePlace",FieldName="slottypePlace",SlotKey="/typePlace;1;0",Position=2,CameFromFloat=false) public String getSlottypePlace(){
    return this.slottypePlace;
  }
  @IDataAnnotation(OriginalFieldName="typePlace",FieldName="slottypePlace",SlotKey="/typePlace;1;0",Position=2,CameFromFloat=false) public void setSlottypePlace(  String paramtypePlace){
    this.slottypePlace=paramtypePlace;
  }
}
