package pkgRule_CustomerOnboardingAndVerification.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="Rule_CustomerOnboardingAndVerification",DataModelName="DM_DATA_RN01_V2",EventTypeName="") public class DMDM_DATA_RN01_V2 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private String slotPolygon;
  private String slotCountry;
  @IDataAnnotation(OriginalFieldName="Polygon",FieldName="slotPolygon",SlotKey="/Polygon;1;0",Position=0,CameFromFloat=false) public String getSlotPolygon(){
    return this.slotPolygon;
  }
  @IDataAnnotation(OriginalFieldName="Polygon",FieldName="slotPolygon",SlotKey="/Polygon;1;0",Position=0,CameFromFloat=false) public void setSlotPolygon(  String paramPolygon){
    this.slotPolygon=paramPolygon;
  }
  @IDataAnnotation(OriginalFieldName="Country",FieldName="slotCountry",SlotKey="/Country;1;0",Position=1,CameFromFloat=false) public String getSlotCountry(){
    return this.slotCountry;
  }
  @IDataAnnotation(OriginalFieldName="Country",FieldName="slotCountry",SlotKey="/Country;1;0",Position=1,CameFromFloat=false) public void setSlotCountry(  String paramCountry){
    this.slotCountry=paramCountry;
  }
}
