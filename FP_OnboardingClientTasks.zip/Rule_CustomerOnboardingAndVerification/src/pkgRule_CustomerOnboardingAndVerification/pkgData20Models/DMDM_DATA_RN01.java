package pkgRule_CustomerOnboardingAndVerification.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="Rule_CustomerOnboardingAndVerification",DataModelName="DM_DATA_RN01",EventTypeName="") public class DMDM_DATA_RN01 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private Double slotLAT_MIN;
  private Double slotLAT_MAX;
  private Double slotLONG_MIN;
  private Double slotLONG_MAX;
  private Boolean slotReturn;
  @IDataAnnotation(OriginalFieldName="LAT_MIN",FieldName="slotLAT_MIN",SlotKey="/LAT_MIN;3.5;0",Position=0,CameFromFloat=true) public Double getSlotLAT_MIN(){
    return this.slotLAT_MIN;
  }
  @IDataAnnotation(OriginalFieldName="LAT_MIN",FieldName="slotLAT_MIN",SlotKey="/LAT_MIN;3.5;0",Position=0,CameFromFloat=true) public void setSlotLAT_MIN(  Double paramLAT_MIN){
    this.slotLAT_MIN=paramLAT_MIN;
  }
  @IDataAnnotation(OriginalFieldName="LAT_MIN",FieldName="slotLAT_MIN",SlotKey="/LAT_MIN;3.5;0",Position=0,CameFromFloat=true) public void setSlotLAT_MIN(  String paramLAT_MIN){
    if (paramLAT_MIN != null) {
      this.slotLAT_MIN=Double.valueOf(paramLAT_MIN);
    }
 else {
      this.slotLAT_MIN=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="LAT_MIN",FieldName="slotLAT_MIN",SlotKey="/LAT_MIN;3.5;0",Position=0,CameFromFloat=true) public void setSlotLAT_MIN(  Long paramLAT_MIN){
    if (paramLAT_MIN != null) {
      this.slotLAT_MIN=Double.valueOf(paramLAT_MIN);
    }
 else {
      this.slotLAT_MIN=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="LAT_MAX",FieldName="slotLAT_MAX",SlotKey="/LAT_MAX;3.5;0",Position=1,CameFromFloat=true) public Double getSlotLAT_MAX(){
    return this.slotLAT_MAX;
  }
  @IDataAnnotation(OriginalFieldName="LAT_MAX",FieldName="slotLAT_MAX",SlotKey="/LAT_MAX;3.5;0",Position=1,CameFromFloat=true) public void setSlotLAT_MAX(  Double paramLAT_MAX){
    this.slotLAT_MAX=paramLAT_MAX;
  }
  @IDataAnnotation(OriginalFieldName="LAT_MAX",FieldName="slotLAT_MAX",SlotKey="/LAT_MAX;3.5;0",Position=1,CameFromFloat=true) public void setSlotLAT_MAX(  String paramLAT_MAX){
    if (paramLAT_MAX != null) {
      this.slotLAT_MAX=Double.valueOf(paramLAT_MAX);
    }
 else {
      this.slotLAT_MAX=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="LAT_MAX",FieldName="slotLAT_MAX",SlotKey="/LAT_MAX;3.5;0",Position=1,CameFromFloat=true) public void setSlotLAT_MAX(  Long paramLAT_MAX){
    if (paramLAT_MAX != null) {
      this.slotLAT_MAX=Double.valueOf(paramLAT_MAX);
    }
 else {
      this.slotLAT_MAX=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="LONG_MIN",FieldName="slotLONG_MIN",SlotKey="/LONG_MIN;3.5;0",Position=2,CameFromFloat=true) public Double getSlotLONG_MIN(){
    return this.slotLONG_MIN;
  }
  @IDataAnnotation(OriginalFieldName="LONG_MIN",FieldName="slotLONG_MIN",SlotKey="/LONG_MIN;3.5;0",Position=2,CameFromFloat=true) public void setSlotLONG_MIN(  Double paramLONG_MIN){
    this.slotLONG_MIN=paramLONG_MIN;
  }
  @IDataAnnotation(OriginalFieldName="LONG_MIN",FieldName="slotLONG_MIN",SlotKey="/LONG_MIN;3.5;0",Position=2,CameFromFloat=true) public void setSlotLONG_MIN(  String paramLONG_MIN){
    if (paramLONG_MIN != null) {
      this.slotLONG_MIN=Double.valueOf(paramLONG_MIN);
    }
 else {
      this.slotLONG_MIN=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="LONG_MIN",FieldName="slotLONG_MIN",SlotKey="/LONG_MIN;3.5;0",Position=2,CameFromFloat=true) public void setSlotLONG_MIN(  Long paramLONG_MIN){
    if (paramLONG_MIN != null) {
      this.slotLONG_MIN=Double.valueOf(paramLONG_MIN);
    }
 else {
      this.slotLONG_MIN=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="LONG_MAX",FieldName="slotLONG_MAX",SlotKey="/LONG_MAX;3.5;0",Position=3,CameFromFloat=true) public Double getSlotLONG_MAX(){
    return this.slotLONG_MAX;
  }
  @IDataAnnotation(OriginalFieldName="LONG_MAX",FieldName="slotLONG_MAX",SlotKey="/LONG_MAX;3.5;0",Position=3,CameFromFloat=true) public void setSlotLONG_MAX(  Double paramLONG_MAX){
    this.slotLONG_MAX=paramLONG_MAX;
  }
  @IDataAnnotation(OriginalFieldName="LONG_MAX",FieldName="slotLONG_MAX",SlotKey="/LONG_MAX;3.5;0",Position=3,CameFromFloat=true) public void setSlotLONG_MAX(  String paramLONG_MAX){
    if (paramLONG_MAX != null) {
      this.slotLONG_MAX=Double.valueOf(paramLONG_MAX);
    }
 else {
      this.slotLONG_MAX=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="LONG_MAX",FieldName="slotLONG_MAX",SlotKey="/LONG_MAX;3.5;0",Position=3,CameFromFloat=true) public void setSlotLONG_MAX(  Long paramLONG_MAX){
    if (paramLONG_MAX != null) {
      this.slotLONG_MAX=Double.valueOf(paramLONG_MAX);
    }
 else {
      this.slotLONG_MAX=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="Return",FieldName="slotReturn",SlotKey="/Return;3.1;0",Position=4,CameFromFloat=false) public Boolean getSlotReturn(){
    return this.slotReturn;
  }
  @IDataAnnotation(OriginalFieldName="Return",FieldName="slotReturn",SlotKey="/Return;3.1;0",Position=4,CameFromFloat=false) public void setSlotReturn(  Boolean paramReturn){
    this.slotReturn=paramReturn;
  }
}
