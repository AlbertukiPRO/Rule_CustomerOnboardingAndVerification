package pkgRule_CustomerOnboardingAndVerification.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="Rule_CustomerOnboardingAndVerification",DataModelName="DM_IN_RN10",EventTypeName="") public class DMDM_IN_RN10 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private String slotcountry;
  private String slotcp;
  private String slotstate;
  private String slotcity;
  private String slotmpo;
  private String slotcolonia;
  private String slotexteriorNo;
  private String slotstreet;
  @IDataAnnotation(OriginalFieldName="country",FieldName="slotcountry",SlotKey="/country;1;0",Position=0,CameFromFloat=false) public String getSlotcountry(){
    return this.slotcountry;
  }
  @IDataAnnotation(OriginalFieldName="country",FieldName="slotcountry",SlotKey="/country;1;0",Position=0,CameFromFloat=false) public void setSlotcountry(  String paramcountry){
    this.slotcountry=paramcountry;
  }
  @IDataAnnotation(OriginalFieldName="cp",FieldName="slotcp",SlotKey="/cp;1;0",Position=1,CameFromFloat=false) public String getSlotcp(){
    return this.slotcp;
  }
  @IDataAnnotation(OriginalFieldName="cp",FieldName="slotcp",SlotKey="/cp;1;0",Position=1,CameFromFloat=false) public void setSlotcp(  String paramcp){
    this.slotcp=paramcp;
  }
  @IDataAnnotation(OriginalFieldName="state",FieldName="slotstate",SlotKey="/state;1;0",Position=2,CameFromFloat=false) public String getSlotstate(){
    return this.slotstate;
  }
  @IDataAnnotation(OriginalFieldName="state",FieldName="slotstate",SlotKey="/state;1;0",Position=2,CameFromFloat=false) public void setSlotstate(  String paramstate){
    this.slotstate=paramstate;
  }
  @IDataAnnotation(OriginalFieldName="city",FieldName="slotcity",SlotKey="/city;1;0",Position=3,CameFromFloat=false) public String getSlotcity(){
    return this.slotcity;
  }
  @IDataAnnotation(OriginalFieldName="city",FieldName="slotcity",SlotKey="/city;1;0",Position=3,CameFromFloat=false) public void setSlotcity(  String paramcity){
    this.slotcity=paramcity;
  }
  @IDataAnnotation(OriginalFieldName="mpo",FieldName="slotmpo",SlotKey="/mpo;1;0",Position=4,CameFromFloat=false) public String getSlotmpo(){
    return this.slotmpo;
  }
  @IDataAnnotation(OriginalFieldName="mpo",FieldName="slotmpo",SlotKey="/mpo;1;0",Position=4,CameFromFloat=false) public void setSlotmpo(  String parammpo){
    this.slotmpo=parammpo;
  }
  @IDataAnnotation(OriginalFieldName="colonia",FieldName="slotcolonia",SlotKey="/colonia;1;0",Position=5,CameFromFloat=false) public String getSlotcolonia(){
    return this.slotcolonia;
  }
  @IDataAnnotation(OriginalFieldName="colonia",FieldName="slotcolonia",SlotKey="/colonia;1;0",Position=5,CameFromFloat=false) public void setSlotcolonia(  String paramcolonia){
    this.slotcolonia=paramcolonia;
  }
  @IDataAnnotation(OriginalFieldName="exteriorNo",FieldName="slotexteriorNo",SlotKey="/exteriorNo;1;0",Position=6,CameFromFloat=false) public String getSlotexteriorNo(){
    return this.slotexteriorNo;
  }
  @IDataAnnotation(OriginalFieldName="exteriorNo",FieldName="slotexteriorNo",SlotKey="/exteriorNo;1;0",Position=6,CameFromFloat=false) public void setSlotexteriorNo(  String paramexteriorNo){
    this.slotexteriorNo=paramexteriorNo;
  }
  @IDataAnnotation(OriginalFieldName="street",FieldName="slotstreet",SlotKey="/street;1;0",Position=7,CameFromFloat=false) public String getSlotstreet(){
    return this.slotstreet;
  }
  @IDataAnnotation(OriginalFieldName="street",FieldName="slotstreet",SlotKey="/street;1;0",Position=7,CameFromFloat=false) public void setSlotstreet(  String paramstreet){
    this.slotstreet=paramstreet;
  }
}
