package pkgRule_CustomerOnboardingAndVerification.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="Rule_CustomerOnboardingAndVerification",DataModelName="DM_IN_RN05",EventTypeName="") public class DMDM_IN_RN05 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private String slotnationality;
  @IDataAnnotation(OriginalFieldName="nationality",FieldName="slotnationality",SlotKey="/nationality;1;0",Position=0,CameFromFloat=false) public String getSlotnationality(){
    return this.slotnationality;
  }
  @IDataAnnotation(OriginalFieldName="nationality",FieldName="slotnationality",SlotKey="/nationality;1;0",Position=0,CameFromFloat=false) public void setSlotnationality(  String paramnationality){
    this.slotnationality=paramnationality;
  }
}
