package pkgRule_CustomerOnboardingAndVerification.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="Rule_CustomerOnboardingAndVerification",DataModelName="DM_DATA_RN07",EventTypeName="") public class DMDM_DATA_RN07 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private Long slotMONTH_MAX;
  private Boolean slotReturn;
  @IDataAnnotation(OriginalFieldName="MONTH_MAX",FieldName="slotMONTH_MAX",SlotKey="/MONTH_MAX;3.7;0",Position=0,CameFromFloat=false) public Long getSlotMONTH_MAX(){
    return this.slotMONTH_MAX;
  }
  @IDataAnnotation(OriginalFieldName="MONTH_MAX",FieldName="slotMONTH_MAX",SlotKey="/MONTH_MAX;3.7;0",Position=0,CameFromFloat=false) public void setSlotMONTH_MAX(  Long paramMONTH_MAX){
    this.slotMONTH_MAX=paramMONTH_MAX;
  }
  @IDataAnnotation(OriginalFieldName="MONTH_MAX",FieldName="slotMONTH_MAX",SlotKey="/MONTH_MAX;3.7;0",Position=0,CameFromFloat=false) public void setSlotMONTH_MAX(  String paramMONTH_MAX){
    if (paramMONTH_MAX != null) {
      this.slotMONTH_MAX=Long.valueOf(paramMONTH_MAX);
    }
 else {
      this.slotMONTH_MAX=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="MONTH_MAX",FieldName="slotMONTH_MAX",SlotKey="/MONTH_MAX;3.7;0",Position=0,CameFromFloat=false) public void setSlotMONTH_MAX(  Double paramMONTH_MAX){
    if (paramMONTH_MAX != null) {
      this.slotMONTH_MAX=paramMONTH_MAX.longValue();
    }
 else {
      this.slotMONTH_MAX=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="Return",FieldName="slotReturn",SlotKey="/Return;3.1;0",Position=1,CameFromFloat=false) public Boolean getSlotReturn(){
    return this.slotReturn;
  }
  @IDataAnnotation(OriginalFieldName="Return",FieldName="slotReturn",SlotKey="/Return;3.1;0",Position=1,CameFromFloat=false) public void setSlotReturn(  Boolean paramReturn){
    this.slotReturn=paramReturn;
  }
}
