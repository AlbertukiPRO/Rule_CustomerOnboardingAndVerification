package pkgRule_CustomerOnboardingAndVerification.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="Rule_CustomerOnboardingAndVerification",DataModelName="DM_IN_RN18",EventTypeName="") public class DMDM_IN_RN18 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private String slotresponse;
  private String slotcategory;
  @IDataAnnotation(OriginalFieldName="response",FieldName="slotresponse",SlotKey="/response;1;0",Position=0,CameFromFloat=false) public String getSlotresponse(){
    return this.slotresponse;
  }
  @IDataAnnotation(OriginalFieldName="response",FieldName="slotresponse",SlotKey="/response;1;0",Position=0,CameFromFloat=false) public void setSlotresponse(  String paramresponse){
    this.slotresponse=paramresponse;
  }
  @IDataAnnotation(OriginalFieldName="category",FieldName="slotcategory",SlotKey="/category;1;0",Position=1,CameFromFloat=false) public String getSlotcategory(){
    return this.slotcategory;
  }
  @IDataAnnotation(OriginalFieldName="category",FieldName="slotcategory",SlotKey="/category;1;0",Position=1,CameFromFloat=false) public void setSlotcategory(  String paramcategory){
    this.slotcategory=paramcategory;
  }
}
