package pkgRule_CustomerOnboardingAndVerification.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
import java.util.Date;
import java.util.Date;
@IRuleAnnotation(RuleProjectName="Rule_CustomerOnboardingAndVerification",DataModelName="DM_IN_RN15",EventTypeName="") public class DMDM_IN_RN15 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private Date slotdate;
  @IDataAnnotation(OriginalFieldName="date",FieldName="slotdate",SlotKey="/date;3.9;0",Position=0,CameFromFloat=false) public Date getSlotdate(){
    return this.slotdate;
  }
  @IDataAnnotation(OriginalFieldName="date",FieldName="slotdate",SlotKey="/date;3.9;0",Position=0,CameFromFloat=false) public void setSlotdate(  Date paramdate){
    this.slotdate=paramdate;
  }
}
