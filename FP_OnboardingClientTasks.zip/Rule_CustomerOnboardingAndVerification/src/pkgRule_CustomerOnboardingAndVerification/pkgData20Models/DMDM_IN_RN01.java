package pkgRule_CustomerOnboardingAndVerification.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="Rule_CustomerOnboardingAndVerification",DataModelName="DM_IN_RN01",EventTypeName="") public class DMDM_IN_RN01 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private Double slotlong;
  private Double slotlat;
  @IDataAnnotation(OriginalFieldName="long",FieldName="slotlong",SlotKey="/long;3.5;0",Position=0,CameFromFloat=true) public Double getSlotlong(){
    return this.slotlong;
  }
  @IDataAnnotation(OriginalFieldName="long",FieldName="slotlong",SlotKey="/long;3.5;0",Position=0,CameFromFloat=true) public void setSlotlong(  Double paramlong){
    this.slotlong=paramlong;
  }
  @IDataAnnotation(OriginalFieldName="long",FieldName="slotlong",SlotKey="/long;3.5;0",Position=0,CameFromFloat=true) public void setSlotlong(  String paramlong){
    if (paramlong != null) {
      this.slotlong=Double.valueOf(paramlong);
    }
 else {
      this.slotlong=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="long",FieldName="slotlong",SlotKey="/long;3.5;0",Position=0,CameFromFloat=true) public void setSlotlong(  Long paramlong){
    if (paramlong != null) {
      this.slotlong=Double.valueOf(paramlong);
    }
 else {
      this.slotlong=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="lat",FieldName="slotlat",SlotKey="/lat;3.5;0",Position=1,CameFromFloat=true) public Double getSlotlat(){
    return this.slotlat;
  }
  @IDataAnnotation(OriginalFieldName="lat",FieldName="slotlat",SlotKey="/lat;3.5;0",Position=1,CameFromFloat=true) public void setSlotlat(  Double paramlat){
    this.slotlat=paramlat;
  }
  @IDataAnnotation(OriginalFieldName="lat",FieldName="slotlat",SlotKey="/lat;3.5;0",Position=1,CameFromFloat=true) public void setSlotlat(  String paramlat){
    if (paramlat != null) {
      this.slotlat=Double.valueOf(paramlat);
    }
 else {
      this.slotlat=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="lat",FieldName="slotlat",SlotKey="/lat;3.5;0",Position=1,CameFromFloat=true) public void setSlotlat(  Long paramlat){
    if (paramlat != null) {
      this.slotlat=Double.valueOf(paramlat);
    }
 else {
      this.slotlat=null;
    }
  }
}
